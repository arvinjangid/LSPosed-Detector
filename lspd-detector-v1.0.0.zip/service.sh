#!/system/bin/sh
# LSPosed Detector v1.0.0 — service.sh
# Author: Arvin Jangid
# WebUI is the primary interface. This just writes a boot log to Downloads.
LOG="/sdcard/Download/lspd-detect.log"
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 5
mkdir -p /sdcard/Download 2>/dev/null
L() { echo "[$(date '+%H:%M:%S')] $*" >> "$LOG"; }
echo "" >> "$LOG"
L "=== LSPosed Detector boot log $(date) ==="
L "Use WebUI (KSU Manager → lspd-detector → Open) for full scan"
L ""
L "Quick prop check:"
for p in ro.relsposed.version ro.relsposed.active ro.lspd.version ro.zygisk.enabled ro.build.tags ro.debuggable ro.secure; do
    v=$(getprop "$p" 2>/dev/null)
    L "  $p = ${v:-<absent>}"
done
L ""
L "Zygote maps suspicious count:"
for proc in zygote zygote64; do
    pid=$(pidof "$proc" 2>/dev/null | awk '{print $1}')
    if [ -n "$pid" ]; then
        n=$(grep -icE "lspd|xposed|lsplant|relsposed" /proc/$pid/maps 2>/dev/null || echo 0)
        L "  $proc pid=$pid: $n suspicious lines"
    fi
done
L "=== boot log done ==="
